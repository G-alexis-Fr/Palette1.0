﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace ColorPicker
{
    public partial class Palette : Form
    {
        public Palette()
        {
            InitializeComponent();
            ValeurTxtBox();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            panel1.BackColor = Color.FromArgb(TBarRed.Value, TBarGreen.Value, TBarBlue.Value);
        }

        private void panneauCouleurToolStripMenuItem_Click(object sender, EventArgs e)
        {
            colorDialog1.FullOpen = true;
            colorDialog1.Color = panel1.BackColor;
            if (colorDialog1.ShowDialog() == DialogResult.OK)
            {
                panel1.BackColor = colorDialog1.Color;
                textBox1.Text = colorDialog1.Color.R.ToString();
                textBox2.Text = colorDialog1.Color.G.ToString();
                textBox3.Text = colorDialog1.Color.B.ToString();
            }
        }

        private string VersRGB(Color A)
        {
            return $"{A.R.ToString()},{A.G.ToString()},{A.B.ToString()}";
        }

        private static string VersHex(Color A)
        {
            return $"#{A.R.ToString("X2")}{A.G.ToString("X2")}{A.B.ToString("X2")}";
        }

        private void copierVersHTMLToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(VersHex(panel1.BackColor));
        }

        private void copierVersRGBToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Clipboard.SetText(VersRGB(panel1.BackColor));
        }

        private void TBarRed_Scroll(object sender, EventArgs e)
        {

            panel1.BackColor = Color.FromArgb(TBarRed.Value, TBarGreen.Value, TBarBlue.Value);
            ValeurTxtBox();
        }

        private void ValeurTxtBox()
        {
            textBox1.Text = TBarRed.Value.ToString();
            textBox2.Text = TBarGreen.Value.ToString();
            textBox3.Text = TBarBlue.Value.ToString();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

            try
            {
                TBarRed.Value = int.Parse(textBox1.Text);
                panel1.BackColor = Color.FromArgb(int.Parse(textBox1.Text), int.Parse(textBox2.Text), int.Parse(textBox3.Text));
            }
            catch (Exception)
            {

            }
        }


        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            try
            {
                TBarGreen.Value = int.Parse(textBox2.Text);
                panel1.BackColor = Color.FromArgb(int.Parse(textBox1.Text), int.Parse(textBox2.Text), int.Parse(textBox3.Text));
            }
            catch (Exception)
            {

            }
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {
            try
            {
                TBarBlue.Value = int.Parse(textBox3.Text);
                panel1.BackColor = Color.FromArgb(int.Parse(textBox1.Text), int.Parse(textBox2.Text), int.Parse(textBox3.Text));
            }
            catch (Exception)
            {

            }
        }
    }
}
