﻿namespace ColorPicker
{
    partial class Palette
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Palette));
            this.TBarRed = new System.Windows.Forms.TrackBar();
            this.TBarGreen = new System.Windows.Forms.TrackBar();
            this.TBarBlue = new System.Windows.Forms.TrackBar();
            this.panel1 = new System.Windows.Forms.Panel();
            this.contextMenuStrip1 = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.copierVersHTMLToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copierVersRGBToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.panneauCouleurToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.LblRed = new System.Windows.Forms.Label();
            this.LblGreen = new System.Windows.Forms.Label();
            this.LblBlue = new System.Windows.Forms.Label();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.colorDialog1 = new System.Windows.Forms.ColorDialog();
            ((System.ComponentModel.ISupportInitialize)(this.TBarRed)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TBarGreen)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TBarBlue)).BeginInit();
            this.contextMenuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // TBarRed
            // 
            this.TBarRed.Cursor = System.Windows.Forms.Cursors.Hand;
            this.TBarRed.Location = new System.Drawing.Point(57, 236);
            this.TBarRed.Maximum = 255;
            this.TBarRed.Name = "TBarRed";
            this.TBarRed.Size = new System.Drawing.Size(137, 45);
            this.TBarRed.TabIndex = 0;
            this.TBarRed.TickStyle = System.Windows.Forms.TickStyle.None;
            this.TBarRed.Value = 255;
            this.TBarRed.Scroll += new System.EventHandler(this.TBarRed_Scroll);
            // 
            // TBarGreen
            // 
            this.TBarGreen.Cursor = System.Windows.Forms.Cursors.Hand;
            this.TBarGreen.Location = new System.Drawing.Point(57, 287);
            this.TBarGreen.Maximum = 255;
            this.TBarGreen.Name = "TBarGreen";
            this.TBarGreen.Size = new System.Drawing.Size(137, 45);
            this.TBarGreen.TabIndex = 1;
            this.TBarGreen.TickStyle = System.Windows.Forms.TickStyle.None;
            this.TBarGreen.Value = 192;
            this.TBarGreen.Scroll += new System.EventHandler(this.TBarRed_Scroll);
            // 
            // TBarBlue
            // 
            this.TBarBlue.Cursor = System.Windows.Forms.Cursors.Hand;
            this.TBarBlue.Location = new System.Drawing.Point(57, 338);
            this.TBarBlue.Maximum = 255;
            this.TBarBlue.Name = "TBarBlue";
            this.TBarBlue.Size = new System.Drawing.Size(137, 45);
            this.TBarBlue.TabIndex = 2;
            this.TBarBlue.TickStyle = System.Windows.Forms.TickStyle.None;
            this.TBarBlue.Value = 192;
            this.TBarBlue.Scroll += new System.EventHandler(this.TBarRed_Scroll);
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(192)))), ((int)(((byte)(192)))));
            this.panel1.ContextMenuStrip = this.contextMenuStrip1;
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(244, 182);
            this.panel1.TabIndex = 3;
            // 
            // contextMenuStrip1
            // 
            this.contextMenuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.copierVersHTMLToolStripMenuItem,
            this.copierVersRGBToolStripMenuItem,
            this.panneauCouleurToolStripMenuItem});
            this.contextMenuStrip1.Name = "contextMenuStrip1";
            this.contextMenuStrip1.Size = new System.Drawing.Size(169, 70);
            // 
            // copierVersHTMLToolStripMenuItem
            // 
            this.copierVersHTMLToolStripMenuItem.Name = "copierVersHTMLToolStripMenuItem";
            this.copierVersHTMLToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.copierVersHTMLToolStripMenuItem.Text = "Copier Vers HTML";
            this.copierVersHTMLToolStripMenuItem.Click += new System.EventHandler(this.copierVersHTMLToolStripMenuItem_Click);
            // 
            // copierVersRGBToolStripMenuItem
            // 
            this.copierVersRGBToolStripMenuItem.Name = "copierVersRGBToolStripMenuItem";
            this.copierVersRGBToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.copierVersRGBToolStripMenuItem.Text = "Copier Vers RGB";
            this.copierVersRGBToolStripMenuItem.Click += new System.EventHandler(this.copierVersRGBToolStripMenuItem_Click);
            // 
            // panneauCouleurToolStripMenuItem
            // 
            this.panneauCouleurToolStripMenuItem.Name = "panneauCouleurToolStripMenuItem";
            this.panneauCouleurToolStripMenuItem.Size = new System.Drawing.Size(168, 22);
            this.panneauCouleurToolStripMenuItem.Text = "Panneau Couleur";
            this.panneauCouleurToolStripMenuItem.Click += new System.EventHandler(this.panneauCouleurToolStripMenuItem_Click);
            // 
            // LblRed
            // 
            this.LblRed.AutoSize = true;
            this.LblRed.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblRed.Location = new System.Drawing.Point(16, 236);
            this.LblRed.Name = "LblRed";
            this.LblRed.Size = new System.Drawing.Size(19, 16);
            this.LblRed.TabIndex = 4;
            this.LblRed.Text = "R";
            // 
            // LblGreen
            // 
            this.LblGreen.AutoSize = true;
            this.LblGreen.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblGreen.Location = new System.Drawing.Point(16, 287);
            this.LblGreen.Name = "LblGreen";
            this.LblGreen.Size = new System.Drawing.Size(19, 16);
            this.LblGreen.TabIndex = 5;
            this.LblGreen.Text = "G";
            // 
            // LblBlue
            // 
            this.LblBlue.AutoSize = true;
            this.LblBlue.Font = new System.Drawing.Font("Microsoft Sans Serif", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblBlue.Location = new System.Drawing.Point(17, 338);
            this.LblBlue.Name = "LblBlue";
            this.LblBlue.Size = new System.Drawing.Size(18, 16);
            this.LblBlue.TabIndex = 6;
            this.LblBlue.Text = "B";
            // 
            // textBox1
            // 
            this.textBox1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox1.Location = new System.Drawing.Point(200, 236);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(26, 13);
            this.textBox1.TabIndex = 7;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // textBox2
            // 
            this.textBox2.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox2.Location = new System.Drawing.Point(200, 287);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(26, 13);
            this.textBox2.TabIndex = 8;
            this.textBox2.TextChanged += new System.EventHandler(this.textBox2_TextChanged);
            // 
            // textBox3
            // 
            this.textBox3.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBox3.Location = new System.Drawing.Point(200, 338);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(26, 13);
            this.textBox3.TabIndex = 9;
            this.textBox3.TextChanged += new System.EventHandler(this.textBox3_TextChanged);
            // 
            // Palette
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(244, 411);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Controls.Add(this.LblBlue);
            this.Controls.Add(this.LblGreen);
            this.Controls.Add(this.LblRed);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.TBarBlue);
            this.Controls.Add(this.TBarGreen);
            this.Controls.Add(this.TBarRed);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximumSize = new System.Drawing.Size(260, 450);
            this.MinimumSize = new System.Drawing.Size(260, 450);
            this.Name = "Palette";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Palette 1.0";
            this.TransparencyKey = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.TBarRed)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TBarGreen)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TBarBlue)).EndInit();
            this.contextMenuStrip1.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TrackBar TBarRed;
        private System.Windows.Forms.TrackBar TBarGreen;
        private System.Windows.Forms.TrackBar TBarBlue;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label LblRed;
        private System.Windows.Forms.Label LblGreen;
        private System.Windows.Forms.Label LblBlue;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private System.Windows.Forms.TextBox textBox3;
        private System.Windows.Forms.ContextMenuStrip contextMenuStrip1;
        private System.Windows.Forms.ToolStripMenuItem copierVersHTMLToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copierVersRGBToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem panneauCouleurToolStripMenuItem;
        private System.Windows.Forms.ColorDialog colorDialog1;
    }
}

